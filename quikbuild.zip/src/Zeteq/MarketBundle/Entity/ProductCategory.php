<?php

namespace Zeteq\MarketBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Criteria;
use APY\DataGridBundle\Grid\Mapping as GRID;

/**
 * @ORM\Entity
 * @ORM\Table(name="product_category")
 * @ORM\HasLifecycleCallbacks
 */
class ProductCategory {

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")

     */
    protected $id;

    /**
     * @ORM\Column(type="string",length=130,  nullable=false)
     *   @GRID\Column(operatorsVisible=false)
     * 
     */
    protected $name;

    /**
     * @Gedmo\Slug(fields={"name"})
     * @ORM\Column(length=128, unique=true, nullable=true)
     */
    private $slug;

    /**
     * @ORM\Column(type="boolean",nullable=true)
     */
    protected $enabled = true;

    /**
     * @ORM\Column(type="boolean",nullable=true)
     */
    protected $is_parent = true;

    /**
     * @ORM\Column(type="text",  nullable=false)
     */
    protected $description;

    /**
     * @ORM\ManyToOne(targetEntity="ProductSection", inversedBy="product_categories")
     * @ORM\JoinColumn(name="product_section_id", referencedColumnName="id",nullable=false)
     * 
     */
    protected $product_section;

    /**
     * @ORM\ManyToMany(targetEntity="Product",mappedBy="categories")
     *
     */
    protected $products;

    /**
     * @ORM\OneToMany(targetEntity="ProductCategory", mappedBy="parent")
     */
    private $children;

    /**
     * @ORM\ManyToOne(targetEntity="ProductCategory", inversedBy="children")
     * @ORM\JoinColumn(name="parent_id", referencedColumnName="id",nullable=true)
     */
    private $parent;

    //////////image uploading begin

    /**
     * @ORM\Column(type="string", length=100,nullable=true)
     */
    protected $image_path;

    /**
     * @var string $image
     * @Assert\File( maxSize = "5024k", mimeTypesMessage = "Please upload a valid Image")
     * @ORM\Column(name="image", type="string", length=255,nullable=true)
     */
    private $image;

    public function getWebPath() {
        return 'upload/category/images/' . $this->getId() . '/' . $this->image_path;
    }

    public function getFullImagePath() {
        return $this->getUploadRootDir() . $this->image_path;
    }

    protected function getUploadRootDir() {
        // the absolute directory path where uploaded documents should be saved
        return __DIR__ . '/../../../../public_html/upload/category/images/' . $this->getId() . '/';
    }

    /**
     * @ORM\PrePersist()
     */
    public function uploadpersistImage() {
        // the file property can be empty if the field is not required
        if (null === $this->image) {
            return;
        }


        $this->image->move($this->getUploadRootDir(), $this->image->getClientOriginalName());

        $this->setImagePath($this->image->getClientOriginalName());
        $this->setImage('');
    }

    /**
     * @ORM\PreUpdate()
     */
    public function uploadupdateImage() {

        if (null === $this->image) {
            return;
        }

        $this->image->move($this->getUploadRootDir(), $this->image->getClientOriginalName());
        $this->setImagePath($this->image->getClientOriginalName());
        $this->setImage('');
    }

    /**
     * @ORM\PreRemove()
     */
    public function removeImage() {
        try {
            unlink($this->getFullImagePath());
        } catch (\Exception $e) {
            
        }
    }

    /////////image uploading end

    public function getEnabledProducts() {
        //      return $this->products;

        $products = $this->getProducts();

        $criteria = Criteria::create()
                ->where(Criteria::expr()->eq("enabled", "1"))
//    ->orderBy(array("created" => Criteria::ASC))
        //   ->setFirstResult(0)
        //  ->setMaxResults(20)
        ;

        $enabled_products = $products->matching($criteria);
        return $enabled_products;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId() {
        return $this->id;
    }

    public function __toString() {
        return $this->getName();
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Store
     */
    public function setDescription($description) {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription() {
        return $this->description;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return ProductCategory
     */
    public function setName($name) {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName() {
        return $this->name;
    }

    /**
     * Set enabled
     *
     * @param boolean $enabled
     * @return ProductCategory
     */
    public function setEnabled($enabled) {
        $this->enabled = $enabled;

        return $this;
    }

    /**
     * Get enabled
     *
     * @return boolean 
     */
    public function getEnabled() {
        return $this->enabled;
    }

    /**
     * Set product_section
     *
     * @param \Zeteq\MarketBundle\Entity\ProductSection $productSection
     * @return ProductCategory
     */
    public function setProductSection(\Zeteq\MarketBundle\Entity\ProductSection $productSection) {
        $this->product_section = $productSection;

        return $this;
    }

    /**
     * Get product_section
     *
     * @return \Zeteq\MarketBundle\Entity\ProductSection 
     */
    public function getProductSection() {
        return $this->product_section;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->products = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add products
     *
     * @param \Zeteq\MarketBundle\Entity\Product $products
     * @return ProductCategory
     */
    public function addProduct(\Zeteq\MarketBundle\Entity\Product $products) {
        $this->products[] = $products;

        return $this;
    }

    /**
     * Remove products
     *
     * @param \Zeteq\MarketBundle\Entity\Product $products
     */
    public function removeProduct(\Zeteq\MarketBundle\Entity\Product $products) {
        $this->products->removeElement($products);
    }

    /**
     * Get products
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getProducts() {
        return $this->products;
    }

    /**
     * Set slug
     *
     * @param string $slug
     * @return ProductCategory
     */
    public function setSlug($slug) {
        $this->slug = $slug;

        return $this;
    }

    /**
     * Get slug
     *
     * @return string 
     */
    public function getSlug() {
        return $this->slug;
    }

    /**
     * Add children
     *
     * @param \Zeteq\MarketBundle\Entity\ProductCategory $children
     * @return ProductCategory
     */
    public function addChildren(\Zeteq\MarketBundle\Entity\ProductCategory $children) {
        $this->children[] = $children;

        return $this;
    }

    /**
     * Remove children
     *
     * @param \Zeteq\MarketBundle\Entity\ProductCategory $children
     */
    public function removeChildren(\Zeteq\MarketBundle\Entity\ProductCategory $children) {
        $this->children->removeElement($children);
    }

    /**
     * Get children
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getChildren() {
        return $this->children;
    }

    /**
     * Set parent
     *
     * @param \Zeteq\MarketBundle\Entity\ProductCategory $parent
     * @return ProductCategory
     */
    public function setParent(\Zeteq\MarketBundle\Entity\ProductCategory $parent = null) {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Get parent
     *
     * @return \Zeteq\MarketBundle\Entity\ProductCategory 
     */
    public function getParent() {
        return $this->parent;
    }

    /**
     * Set is_parent
     *
     * @param boolean $isParent
     * @return ProductCategory
     */
    public function setIsParent($isParent) {
        $this->is_parent = $isParent;

        return $this;
    }

    /**
     * Get is_parent
     *
     * @return boolean 
     */
    public function getIsParent() {
        return $this->is_parent;
    }

    /**
     * Set image_path
     *
     * @param string $imagePath
     * @return ProductCategory
     */
    public function setImagePath($imagePath) {
        $this->image_path = $imagePath;

        return $this;
    }

    /**
     * Get image_path
     *
     * @return string 
     */
    public function getImagePath() {
        return $this->image_path;
    }

    /**
     * Set image
     *
     * @param string $image
     * @return ProductCategory
     */
    public function setImage($image) {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return string 
     */
    public function getImage() {
        return $this->image;
    }

}