<?php

namespace Zeteq\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZeteqUserBundle extends Bundle
{
}
