<?php

namespace Zeteq\FrontBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZeteqFrontBundle extends Bundle
{
}
