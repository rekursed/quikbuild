<?php

namespace Zeteq\MarketBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ZeteqMarketBundle extends Bundle
{
}
